class freecourses_models {
  String Name;
  String imgsrc;
  // int number;
  freecourses_models({
    required this.Name,
    required this.imgsrc,
    // required this.number,
  });
}
