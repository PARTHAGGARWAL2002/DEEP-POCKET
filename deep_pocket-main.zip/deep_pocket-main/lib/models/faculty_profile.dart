class faculty {
  String name;
  String field;
  String department;
  String imgsrc;
  String email;
  String designation;
  String education;
  faculty({
    required this.field,
    required this.department,
    required this.designation,
    required this.email,
    required this.imgsrc,
    required this.name,
    required this.education,
  });
}
